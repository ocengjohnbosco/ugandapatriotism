function welcome(){
if (linker=="") {
	window.open("https://www.patriotismclubs.org.ug/")
}
	else{
		window.open("https://www.npcu.wordpress.com");
	}
}